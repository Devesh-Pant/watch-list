package setup;

public enum State {
    Waiting,
    Sorting,
    Done
}