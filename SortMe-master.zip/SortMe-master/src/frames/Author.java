package frames;

public @interface Author {
    String name();

    String date();
}
