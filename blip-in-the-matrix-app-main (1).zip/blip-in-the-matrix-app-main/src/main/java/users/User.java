package users;

public class User {
    String username;
    String pwd;
    User(){
        username="SAMPLE";
        pwd="Password";
    }
    User(String username, String pwd){
        username=username;
        pwd=pwd;
    }
}
